-- FS25_PaidTeleport (Config File Version)
-- Linux / PC Compatible (FS25)

PaidTeleport = {}
PaidTeleport.enabled = true
PaidTeleport.baseFare = 50.0
PaidTeleport.costPerMeter = 0.08
PaidTeleport.teleportThreshold = 50.0
-- $251 to Teleport from field 74 to 19 on riverbend springs

PaidTeleport.lastX = nil
PaidTeleport.lastY = nil
PaidTeleport.lastZ = nil
PaidTeleport.hasSpawned = false

function PaidTeleport.init()
-- Load configuration from modSettings on startup
PaidTeleport.loadConfig()

if FSBaseMission ~= nil and FSBaseMission.load ~= nil then
    FSBaseMission.load = Utils.overwrittenFunction(FSBaseMission.load, PaidTeleport.onMissionLoad)
    print("[PaidTeleport] Hooked into FSBaseMission.load successfully.")
    elseif BaseMission ~= nil and BaseMission.load ~= nil then
        BaseMission.load = Utils.overwrittenFunction(BaseMission.load, PaidTeleport.onMissionLoad)
        print("[PaidTeleport] Hooked into BaseMission.load successfully.")
        else
            print("[PaidTeleport] ERROR: Could not find base mission load function to hook!")
            end
            end

            function PaidTeleport.loadConfig()
            local xmlPath = getUserProfileAppPath() .. "modSettings/FS25_PaidTeleport.xml"
            local xmlFile = loadXMLFile("PaidTeleportConfig", xmlPath)
            if xmlFile ~= nil and xmlFile ~= 0 then
                PaidTeleport.enabled = getXMLBool(xmlFile, "paidTeleport.enabled") or PaidTeleport.enabled
                PaidTeleport.baseFare = getXMLFloat(xmlFile, "paidTeleport.baseFare") or PaidTeleport.baseFare
                PaidTeleport.costPerMeter = getXMLFloat(xmlFile, "paidTeleport.costPerMeter") or PaidTeleport.costPerMeter
                PaidTeleport.teleportThreshold = getXMLFloat(xmlFile, "paidTeleport.teleportThreshold") or PaidTeleport.teleportThreshold
                delete(xmlFile)
                print("[PaidTeleport] Configuration loaded successfully from modSettings.")
                else
                    PaidTeleport.saveConfig()
                    end
                    end

                    function PaidTeleport.saveConfig()
                    local xmlPath = getUserProfileAppPath() .. "modSettings/FS25_PaidTeleport.xml"
                    local xmlFile = createXMLFile("PaidTeleportConfig", xmlPath, "paidTeleport")
                    if xmlFile ~= nil and xmlFile ~= 0 then
                        setXMLBool(xmlFile, "paidTeleport.enabled", PaidTeleport.enabled)
                        setXMLFloat(xmlFile, "paidTeleport.baseFare", PaidTeleport.baseFare)
                        setXMLFloat(xmlFile, "paidTeleport.costPerMeter", PaidTeleport.costPerMeter)
                        setXMLFloat(xmlFile, "paidTeleport.teleportThreshold", PaidTeleport.teleportThreshold)
                        saveXMLFile(xmlFile)
                        delete(xmlFile)
                        print("[PaidTeleport] Default configuration saved to modSettings.")
                        end
                        end

                        function PaidTeleport.onMissionLoad(mission, superFunc, ...)
                        local result = superFunc(mission, ...)
                        print("[PaidTeleport] Mission loaded! Registering event listener.")
                        addModEventListener(PaidTeleport)
                        PaidTeleport.hasSpawned = false
                        return result
                        end

                        function PaidTeleport:update(dt)
                        if not PaidTeleport.enabled then return end
                            if g_currentMission == nil or not g_currentMission.isLoaded then return end

                                local x, y, z = PaidTeleport:getCurrentPosition()

                                if x == nil or y == nil or z == nil then
                                    return
                                    end

                                    if not PaidTeleport.hasSpawned then
                                        PaidTeleport.lastX = x
                                        PaidTeleport.lastY = y
                                        PaidTeleport.lastZ = z
                                        PaidTeleport.hasSpawned = true
                                        return
                                        end

                                        local distance = MathUtil.vector3Length(x - PaidTeleport.lastX, y - PaidTeleport.lastY, z - PaidTeleport.lastZ)

                                        if distance > PaidTeleport.teleportThreshold and distance < 15000.0 then
                                            PaidTeleport:chargeFare(distance)
                                            end

                                            PaidTeleport.lastX = x
                                            PaidTeleport.lastY = y
                                            PaidTeleport.lastZ = z
                                            end

                                            function PaidTeleport:getCurrentPosition()
                                            if getCamera ~= nil then
                                                local cam = getCamera()
                                                if cam ~= nil and cam ~= 0 then
                                                    return getWorldTranslation(cam)
                                                    end
                                                    end

                                                    if g_currentMission.controlledVehicle ~= nil then
                                                        local veh = g_currentMission.controlledVehicle
                                                        local rootNode = veh.rootNode or (veh.components and veh.components[1] and veh.components[1].node)
                                                        if rootNode ~= nil and rootNode ~= 0 then
                                                            return getWorldTranslation(rootNode)
                                                            end
                                                            end

                                                            if g_currentMission.player ~= nil then
                                                                local player = g_currentMission.player
                                                                local node = player.rootNode or player.node
                                                                if node ~= nil and node ~= 0 then
                                                                    return getWorldTranslation(node)
                                                                    end
                                                                    end

                                                                    return nil, nil, nil
                                                                    end

                                                                    function PaidTeleport:chargeFare(distance)
                                                                    local fare = math.floor(PaidTeleport.baseFare + (distance * PaidTeleport.costPerMeter) + 0.5)
                                                                    local farmId = g_currentMission:getFarmId()

                                                                    if fare > 0 and farmId ~= nil and farmId > 0 and farmId ~= FarmManager.SPECTATOR_FARM_ID then
                                                                        g_currentMission:addMoney(-fare, farmId, MoneyType.OTHER, false, true)

                                                                        local notificationText = string.format("Teleportation Fee: -$%d (%dm)", fare, math.floor(distance + 0.5))

                                                                        if g_currentMission.addIngameNotification ~= nil then
                                                                            g_currentMission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, notificationText)
                                                                            elseif g_currentMission.showBlinkingWarning ~= nil then
                                                                                g_currentMission:showBlinkingWarning(notificationText, 4000)
                                                                                end
                                                                                end
                                                                                end

                                                                                function PaidTeleport:draw() end
                                                                                function PaidTeleport:deleteMap() end

                                                                                PaidTeleport.init()
