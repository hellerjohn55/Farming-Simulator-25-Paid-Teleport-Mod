-- FS25_PaidTeleport (Entity Tracker Engine)
-- Linux / PC Compatible (FS25)

PaidTeleport = {}
PaidTeleport.enabled = true
PaidTeleport.baseFare = 15.0
PaidTeleport.costPerMeter = 0.04
PaidTeleport.teleportThreshold = 50.0

PaidTeleport.lastX = nil
PaidTeleport.lastY = nil
PaidTeleport.lastZ = nil

function PaidTeleport.init()
PaidTeleport.loadConfig()

if FSBaseMission ~= nil and FSBaseMission.update ~= nil then
    FSBaseMission.update = Utils.prependedFunction(FSBaseMission.update, PaidTeleport.updateFrame)
    elseif BaseMission ~= nil and BaseMission.update ~= nil then
        BaseMission.update = Utils.prependedFunction(BaseMission.update, PaidTeleport.updateFrame)
        end
        end

        function PaidTeleport.loadConfig()
        local xmlPath = getUserProfileAppPath() .. "modSettings/FS25_PaidTeleport.xml"
        local xmlFile = loadXMLFile("PaidTeleportConfig", xmlPath)
        if xmlFile ~= nil and xmlFile ~= 0 then
            PaidTeleport.enabled = getXMLBool(xmlFile, "paidTeleport.enabled") or PaidTeleport.enabled
            PaidTeleport.baseFare = getXMLFloat(xmlFile, "paidTeleport.baseFare") or PaidTeleport.baseFare
            PaidTeleport.costPerMeter = getXMLFloat(xmlFile, "paidTeleport.costPerMeter") or PaidTeleport.costPerMeter
            PaidTeleport.teleportThreshold = getXMLFloat(xmlFile, "paidTeleport.teleportThreshold") or PaidTeleport.teleportThreshold
            delete(xmlFile)
            else
                PaidTeleport.saveConfig()
                end
                end

                function PaidTeleport.saveConfig()
                local xmlPath = getUserProfileAppPath() .. "modSettings/FS25_PaidTeleport.xml"
                local xmlFile = createXMLFile("PaidTeleportConfig", xmlPath, "paidTeleport")
                if xmlFile ~= nil and xmlFile ~= 0 then
                    setXMLBool(xmlFile, "paidTeleport.enabled", PaidTeleport.enabled)
                    setXMLFloat(xmlFile, "paidTeleport.baseFare", PaidTeleport.baseFare)
                    setXMLFloat(xmlFile, "paidTeleport.costPerMeter", PaidTeleport.costPerMeter)
                    setXMLFloat(xmlFile, "paidTeleport.teleportThreshold", PaidTeleport.teleportThreshold)
                    saveXMLFile(xmlFile)
                    delete(xmlFile)
                    end
                    end

                    function PaidTeleport.updateFrame(mission, dt)
                    if not PaidTeleport.enabled then return end
                        if mission == nil or not mission.isLoaded or mission.isConstructionMode then return end

                            local x, y, z = PaidTeleport:getValidCoordinates()

                            -- If the fetcher returns nil (because of transition or 0,0,0), skip the frame.
                            if x == nil or y == nil or z == nil then return end

                                -- Initialize the anchor on the very first valid frame
                                if PaidTeleport.lastX == nil then
                                    PaidTeleport.lastX = x
                                    PaidTeleport.lastY = y
                                    PaidTeleport.lastZ = z
                                    return
                                    end

                                    -- Compare current valid coordinates to the last valid coordinates (whether player or vehicle)
                                    local distance = MathUtil.vector3Length(x - PaidTeleport.lastX, y - PaidTeleport.lastY, z - PaidTeleport.lastZ)

                                    -- If the jump is larger than the threshold, charge the fare.
                                    if distance > PaidTeleport.teleportThreshold and distance < 100000.0 then
                                        PaidTeleport:chargeFare(mission, distance)
                                        end

                                        -- Update the anchor to the current valid position
                                        PaidTeleport.lastX = x
                                        PaidTeleport.lastY = y
                                        PaidTeleport.lastZ = z
                                        end

                                        function PaidTeleport:getValidCoordinates()
                                        -- Ensure local player exists
                                        if g_localPlayer == nil then return nil, nil, nil end

                                            local x, y, z = nil, nil, nil

                                            -- 1. Check if the player is actively in a vehicle (This catches Tab jumps instantly)
                                            local currentVehicle = g_localPlayer:getCurrentVehicle()

                                            if currentVehicle ~= nil then
                                                -- We are in a vehicle, get its physical coordinates
                                                local node = currentVehicle.rootNode
                                                if node == nil and currentVehicle.components ~= nil and currentVehicle.components[1] ~= nil then
                                                    node = currentVehicle.components[1].node
                                                    end

                                                    if node ~= nil and node ~= 0 then
                                                        x, y, z = getWorldTranslation(node)
                                                        end

                                                        -- 2. Check if the player is actively walking on foot
                                                        elseif g_localPlayer.isControlled then
                                                            local node = g_localPlayer.rootNode or g_localPlayer.graphicsNode
                                                            if node ~= nil and node ~= 0 then
                                                                x, y, z = getWorldTranslation(node)
                                                                end
                                                                end

                                                                -- 3. The rule: Filter out 0,0,0 engine transitions and falling through the map
                                                                if x ~= nil and y ~= nil and z ~= nil then
                                                                    if (math.abs(x) < 0.1 and math.abs(y) < 0.1 and math.abs(z) < 0.1) or y < -500 then
                                                                        return nil, nil, nil
                                                                        end
                                                                        return x, y, z
                                                                        end

                                                                        return nil, nil, nil
                                                                        end

                                                                        function PaidTeleport:chargeFare(mission, distance)
                                                                        local fare = math.floor(PaidTeleport.baseFare + (distance * PaidTeleport.costPerMeter) + 0.5)
                                                                        local farmId = nil

                                                                        if mission.getFarmId ~= nil then
                                                                            farmId = mission:getFarmId()
                                                                            end

                                                                            if fare > 0 and farmId ~= nil and farmId > 0 and farmId ~= FarmManager.SPECTATOR_FARM_ID then
                                                                                mission:addMoney(-fare, farmId, MoneyType.OTHER, false, true)

                                                                                local notificationText = string.format("Teleportation Fee: -$%d (%dm)", fare, math.floor(distance + 0.5))

                                                                                if mission.addIngameNotification ~= nil then
                                                                                    mission:addIngameNotification(FSBaseMission.INGAME_NOTIFICATION_INFO, notificationText)
                                                                                    else
                                                                                        print("[PaidTeleport] " .. notificationText)
                                                                                        end
                                                                                        end
                                                                                        end

                                                                                        PaidTeleport.init()
